﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Akademia5Gra.Creatures;

namespace Akademia5Gra
{
    class Program
    {
        static void Main(string[] args)
        {
            World word = new World();

            Console.ReadKey();
        }
    }
}
